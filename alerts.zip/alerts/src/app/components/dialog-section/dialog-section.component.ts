import { Component, OnInit , Output, EventEmitter, Input} from '@angular/core';
import { FileService } from '../../services/file-service.service';
@Component({
  selector: 'app-dialog-section',
  templateUrl: './dialog-section.component.html',
  styleUrls: ['./dialog-section.component.scss']
})
export class DialogSectionComponent implements OnInit {
  selectedRecipient: string;
  fileBaseString: string;
  constructor(private fileService: FileService) { }
  @Output() selectedRecipientEmitter = new EventEmitter<any>();
  @Output() fileBaseStringEmitter = new  EventEmitter<any>();
  @Input() recipients = [];
  ngOnInit() {
  }

  getSelectedRecipient(info) {
    this.selectedRecipient = info.detail.selectedOption.textContent;
    this.selectedRecipientEmitter.emit(this.selectedRecipient);
    console.log(this.selectedRecipient);
  }
  onFileChange(event) {
      console.log(event.target.files);
      this.fileService.changeFileToBase64(event.target.files[0]).subscribe((data) => {
        this.fileBaseString = data;
        this.fileBaseStringEmitter.emit(this.fileBaseString);
      });
    }
}
