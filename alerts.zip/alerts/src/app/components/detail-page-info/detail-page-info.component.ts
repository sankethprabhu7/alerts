import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { ShareService } from '../../services/share-service.service';
import { Dialog } from '../../models/dialog';
@Component({
  selector: 'app-detail-page-info',
  templateUrl: './detail-page-info.component.html',
  styleUrls: ['./detail-page-info.component.scss']
})
export class DetailPageInfoComponent implements OnInit {
  @Input() alertDetail: Array<any>;
  @Input() scenario: string;
  @Input() alertName: string;
  @Input() user: string;
  dialogInfo: Dialog;
  constructor(private shareService: ShareService) { }

  ngOnInit() {
  }
  openDialog(typeOfDialog): void {
    this.dialogInfo = {
      show : true,
      type : typeOfDialog
    };
    this.shareService.changeDialogState(this.dialogInfo);
  }
}
