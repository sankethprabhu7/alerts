import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../services/http-service.service';

@Component({
  selector: 'app-main-view',
  templateUrl: './main-view.component.html',
  styleUrls: ['./main-view.component.scss']
})
export class MainViewComponent implements OnInit {
  masterData: any;
  busyState = true;
  user = 'S0009657696';
  constructor(private httpService: HttpService) { }

  ngOnInit() {
    this.getLoggedInUser();
  }

  updateStatus(data: any): void {
    this.masterData = data;
  }

  updateBusyState(state: boolean) {
    this.busyState = state;
  }

  getLoggedInUser() {
    this.httpService.getLoggedInUser().subscribe(user => {
      console.log(user);
      this.user = user;
    },
    error => {
      console.log(error);
    });
  }
}
