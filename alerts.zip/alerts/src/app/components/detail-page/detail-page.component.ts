import { Component, OnInit, Input, OnDestroy, OnChanges } from '@angular/core';
import { ShareService } from '../../services/share-service.service';
import { HttpService } from 'src/app/services/http-service.service';
import { NoteModel } from '../../models/notes';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-detail-page',
  templateUrl: './detail-page.component.html',
  styleUrls: ['./detail-page.component.scss']
})
export class DetailPageComponent implements OnInit, OnDestroy, OnChanges {
  masterData: any;
  alertDetails: any;
  hidden = true;
  error: any;
  detailtext: string;
  noteSubmitArray: Array<NoteModel> = [];
  notesData: NoteModel;
  mydata: any;
  result: any;
  constructor(private alert: ShareService, private httpService: HttpService) {}
  services: Array<Subscription> = [];

  ngOnInit() {
    this.services.push(this.alert.masterState$.subscribe(data => {
      this.masterData = data;
      // this.noteSubmitArray = this.masterData.notes;
    }));
    this.services.push(this.alert.currentAlert$.subscribe(
      alert => this.getDetails(alert),
      error => {
        console.log(error);
      }
    ));
  }

  ngOnChanges() {
    this.services.push(this.alert.currentAlert$.subscribe(
    alert => this.getDetails(alert),
    error => {
      console.log(error);
    }
  ));
  }
  getDetails(alertDetails: any) {
    this.alertDetails = alertDetails;
    this.noteSubmitArray = this.alertDetails.notes; // from ngonint
    console.log('notesarray  ', this.noteSubmitArray); // from ngonint
    console.log('loading details', alertDetails);
    this.hidden = Object.keys(alertDetails).length === 0;
    if (this.hidden) {
      this.error = 'No details found for this alert';
    }
  }

  // tabNoteSubmit() {
  //   // console.log(this.detailtext);
  //   this.notesData = {
  //     alertname: this.masterData.alertname,
  //     user: 'S0009657696',
  //     time: new Date(),
  //     notes: this.detailtext
  //   };
  //   this.httpService.sendNotes(this.notesData).subscribe((data: any) => {
  //     if (data.status === 'successfully saved') {
  //       this.noteSubmitArray.push(this.notesData);
  //     }
  //   });
  // }


  ngOnDestroy() {
    for (const subscriptions of this.services) {
      subscriptions.unsubscribe();
    }
  }
}
