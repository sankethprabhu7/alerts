import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ExcelService } from '../../services/excel-service.service';

@Component({
  selector: 'app-download-section',
  templateUrl: './download-section.component.html',
  styleUrls: ['./download-section.component.scss']
})
export class DownloadSectionComponent implements OnInit {
  @Input() excelData: any;
  @Output() closeDialog = new EventEmitter<any>();
  constructor(private excelService: ExcelService) { }

  ngOnInit() {
  }
  exportExcel() {
    const data = JSON.parse(this.excelData);
    this.excelService.exportAsExcelFile(data, 'contamination_detail');
    this.closeDialog.emit(true);
  }
}
