import { Component, OnInit, Input } from '@angular/core';
import { ShareService } from '../../services/share-service.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
  @Input() master: any;
  hidden = false;
  constructor(private alert: ShareService) { }

  ngOnInit() {
  }
}
