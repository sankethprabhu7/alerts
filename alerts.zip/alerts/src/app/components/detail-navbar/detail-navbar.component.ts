import { Component, OnInit, OnDestroy } from '@angular/core';
import { ShareService } from '../../services/share-service.service';
import { Dialog } from '../../models/dialog';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-detail-navbar',
  templateUrl: './detail-navbar.component.html',
  styleUrls: ['./detail-navbar.component.scss']
})
export class DetailNavbarComponent implements OnInit, OnDestroy {
  alertName: string;
  dialogInfo: Dialog;
  services: Array<Subscription> = [];
  constructor(private shareService: ShareService) { }

  ngOnInit() {
    this.services.push(this.shareService.currentAlert$.subscribe((alertname: string) => {
      this.alertName = alertname;
    }));
  }
  forward() {
    this.dialogInfo = {
      show : true,
      type : 'forward'
    };
    this.shareService.changeDialogState(this.dialogInfo);
  }

  ngOnDestroy() {
    for (const subscriptions of this.services) {
      subscriptions.unsubscribe();
    }
  }
}
