import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-footer',
  templateUrl: './detail-footer.component.html',
  styleUrls: ['./detail-footer.component.scss']
})
export class DetailFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
