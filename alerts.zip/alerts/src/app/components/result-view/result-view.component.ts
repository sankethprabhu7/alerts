import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Input
} from '@angular/core';
import { ExcelService } from '../../services/excel-service.service';
import { ShareService } from '../../services/share-service.service';
import { HttpService } from '../../services/http-service.service';
// import { FileService } from '../../services/file-service.service';
import { Dialog } from '../../models/dialog';

@Component({
  selector: 'app-result-view',
  templateUrl: './result-view.component.html',
  styleUrls: ['./result-view.component.scss']
})
export class ResultViewComponent implements OnInit {
  @ViewChild('resultDialog', { static: false }) oDialog: ElementRef;
  show: boolean;
  type = 'Result';
  selectedRecipient: string;
  recipients = [];
  errorMsg: string;
  successMsg: string;
  fileBaseString: any;
  @Input() user: string;
  @Input() alertDetail: any;
  @Input() alertName: string;
  busyState = false;
  constructor(
    private excelService: ExcelService,
    private shareService: ShareService,
    private httpService: HttpService,
    // private fileService: FileService
  ) {}

  ngOnInit() {
    this.shareService.resultDialogState$.subscribe((state: Dialog) => {
      this.show = state.show;
      if (this.show) {
        this.type = state.type;
        this.errorMsg = state.error;
        this.open();
      }
    });
  }
  openSource() {
    window.open('https://sap.github.io/ui5-webcomponents/');
    this.close();
  }
  open() {
    console.log(this.type);
    if (this.type === 'forward') {
      this.busyState = true;
      this.httpService.getRecipients().subscribe(
        response => {
          console.log(response);
          this.recipients = response;
          this.selectedRecipient = this.recipients[0];
        },
        error => {
          this.showError(error);
        },
        () => {
            console.log('completed ');
            this.busyState = false;
            this.openDialogBox();
        }
      );
    } else {
      this.openDialogBox();
    }
  }
  openDialogBox() {
    this.oDialog.nativeElement.open();
  }
  close() {
    this.oDialog.nativeElement.close();
  }
  // getSelectedRecipient(info) {
  //   this.selectedRecipient = info.detail.selectedOption.textContent;
  //   console.log(this.selectedRecipient);
  // }
  forward() {
    this.close();
    this.busyState = true;
    this.httpService.forward(this.selectedRecipient, this.alertName, this.fileBaseString, this.user).subscribe(
      response => {
        this.showSuccess(response.status);
      },
      error => {
        this.showError = error;
      },
      () => {
          this.busyState = false;
          this.openDialogBox();
      }
    );
  }

  getMessage(message: string) {
    this.fileBaseString = message;
  }

  showSuccess(msg: string) {
    this.show = true;
    this.type = 'success';
    this.successMsg = msg;
    console.log('opening');
  }
  showError(error) {
    this.show = true;
    this.type = 'error';
    this.errorMsg = error;
  }

  // onFileChange(event) {
  //   console.log(event.target.files);
  //   this.fileService.changeFileToBase64(event.target.files[0]).subscribe((data) => {
  //     this.fileBaseString = data;
  //   });
  // }
}
