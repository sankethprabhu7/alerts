import { Component, OnInit, Input, EventEmitter, Output, OnChanges , AfterViewInit} from '@angular/core';
import { HttpService } from 'src/app/services/http-service.service';
import { NoteModel } from '../../models/notes';
@Component({
  selector: 'app-detail-page-notes',
  templateUrl: './detail-page-notes.component.html',
  styleUrls: ['./detail-page-notes.component.scss']
})
export class DetailPageNotesComponent implements OnInit, OnChanges , AfterViewInit {

  constructor(private httpService: HttpService) {
  }
  detailtext: string;
  notesData: NoteModel;
  noteSubmitArray1;
  @Input() masterData: any;
  @Input() noteSubmitArray: Array<any> ;
  // @Output() noteSubmitArrayEmitter = new EventEmitter<any>();
  ngOnInit() {
    console.log('this.noteSubmitArray');
    console.log(this.noteSubmitArray);
    console.log('this is notes' + JSON.stringify(this.noteSubmitArray));
  }
  ngOnChanges() {
    console.log('this.noteSubmitArray');
    console.log('this is notes' + this.noteSubmitArray);
    this.noteSubmitArray1 = Object.values(this.noteSubmitArray);
    console.log(this.noteSubmitArray1);
  }
  ngAfterViewInit() {
  }
  tabNoteSubmit() {
    // console.log(this.detailtext);
    this.notesData = {
      user: 'S0009657696',
      alertname: this.masterData.alertname,
      time: new Date(),
      notes: this.detailtext
    };
    this.httpService.sendNotes(this.notesData).subscribe((data: any) => {
      if (data.status === 'successfully saved') {
        this.noteSubmitArray1.push({
        notes: this.notesData.notes,
        user: this.notesData.user,
        timestamp: this.notesData.time});
      }
    });
    this.ngOnChanges();
    this.ngOnInit();
  }


}
