import { Component, OnInit , Input} from '@angular/core';

@Component({
  selector: 'app-success-section',
  templateUrl: './success-section.component.html',
  styleUrls: ['./success-section.component.scss']
})
export class SuccessSectionComponent implements OnInit {
  @Input() successMsg: any;

  constructor() { }

  ngOnInit() {
  }

}
