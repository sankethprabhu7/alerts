import { Component, OnInit} from '@angular/core';
import { ShareService } from '../../services/share-service.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  constructor(private filterService: ShareService) { }
  ngOnInit() {
  }
  filter(event: any) {
    const searchField = event.target.value;
    this.filterService.filter(searchField);
  }
}
