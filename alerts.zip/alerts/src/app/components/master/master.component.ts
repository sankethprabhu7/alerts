import { Component, OnInit, Output, EventEmitter, OnDestroy, Input } from '@angular/core';
import { ShareService } from '../../services/share-service.service';
import { HttpService } from '../../services/http-service.service';
import { Dialog } from '../../models/dialog';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-master',
  templateUrl: './master.component.html',
  styleUrls: ['./master.component.scss']
})
export class MasterComponent implements OnInit, OnDestroy {
  oData: any = { alerts: [] };
  @Input() userName: string;
  originalData: any = { alerts: [] };
  @Output() masterData = new EventEmitter<any>();
  @Output() busyEvent = new EventEmitter<boolean>();
  dialogInfo: Dialog;
  services: Array<Subscription> = [];
  constructor(
    private shareService: ShareService,
    private httpService: HttpService
  ) { }

  ngOnInit() {
    this.userName = 'S0009657696';
    this.services.push(this.httpService.getAlerts(this.userName).subscribe(alerts => {
      console.log(alerts);
      if (alerts.length === 0) {
        this.busyEvent.emit(false);
        const dialogData = this.shareService.showError('No alert found for the user ' + this.userName);
        this.shareService.changeDialogState(dialogData);
      } else {
        this.oData.alerts = alerts;
        this.originalData.alerts = alerts;
        console.log(alerts);
        this.handleChangeSelection(this.oData.alerts[0]);
      }
    },
      (error) => {
        this.shareService.showError(error);
      }));
    this.services.push(this.shareService.filterTextState$.subscribe(filterData => {
      console.log(filterData);
      if (filterData !== '') {
        this.oData.alerts = this.originalData.alerts.filter(param => {
          return (
            param.alertname.indexOf(filterData) > -1 ||
            param.user_id.indexOf(filterData) > -1 ||
            param.alertstatus.indexOf(filterData) > -1
          );
        });
      } else {
        this.oData.alerts = this.originalData.alerts;
      }
    }));
  }
  handleChangeSelection(alert: any): void {
    this.busyEvent.emit(true);
    const scenario = alert.scenario;
    if (scenario === 'Payment Anomaly') {
    this.services.push(this.httpService.getAlertData(alert.alertname, 0 ).subscribe(info => {
      const note = Object.values(info.notes);
      this.shareService.changeMasterData({
        status: alert.alertstatus,
        scenario: alert.scenario,
        alertname: alert.alertname,
        notes: note
      });
      this.shareService.changeAlert(info);
      setTimeout(() => {
        this.busyEvent.emit(false);
      }, 1000);
    }));
  } else {
    this.services.push(this.httpService.getAlertData(alert.alertname, 1 ).subscribe(info => {
      const note = Object.values(info.notes);
      this.shareService.changeMasterData({
        status: alert.alertstatus,
        scenario: alert.scenario,
        alertname: alert.alertname,
        notes: note
      });
      this.shareService.changeAlert(info);
      setTimeout(() => {
        this.busyEvent.emit(false);
      }, 1000);
    }));

  }

  }

  ngOnDestroy() {
    for (const subscriptions of this.services) {
      subscriptions.unsubscribe();
    }
  }
}
