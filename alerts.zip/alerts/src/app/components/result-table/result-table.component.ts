import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { HttpService } from 'src/app/services/http-service.service';

@Component({
  selector: 'app-result-table',
  templateUrl: './result-table.component.html',
  styleUrls: ['./result-table.component.scss']
})
export class ResultTableComponent implements OnInit, OnChanges {
  @Input() alertDetails: any;
  @Input() duplists: Array<any>;
  @Input() scenario;
  result: Array<any> = [];
  test: Array<any> = [];
  temparray: Array<any> = [];
  checkedarray: Array<any> = [];
  object1 = Object;
  t = true;
  constructor(private httpService: HttpService) {
    //  this.mysfun();

  }

  ngOnInit() {
    console.log(this.alertDetails);
    // this.result = JSON.parse(this.alertDetails);
    this.checkedarray.length = 0;

    this.test = this.duplists;
  }
  ngOnChanges() {
    console.log(this.alertDetails);
    this.result = JSON.parse(this.alertDetails);
    // this.result = Object.assign({}, this.result );
    this.temparray = this.result;
    this.checkedarray.length = 0;
    this.test = this.duplists;
  }

  mycheckevent(event) {
    if (event.target.checked === true) {
      this.checkedarray.push(event.target.text);
    } else {
      this.checkedarray.splice(this.checkedarray.findIndex(item => item === event.target.text), 1);
    }
    console.log('checked array :' + this.checkedarray);
  }
  checkDuplicate() {
    this.httpService.sendCheckData(this.checkedarray)
      .subscribe(
        result => {
          console.log(result);
        }
      );
  }
  funhide() {
    let i;
    if (this.t === true) {
      this.t = false;
      for (i = 0; i < this.test.length; i++) {
        this.result.splice(this.result.findIndex(item => item.index === this.test[i]), 1);
      }
    } else {
      this.t = true;
      this.result = JSON.parse(this.alertDetails);
    }
  }
}
