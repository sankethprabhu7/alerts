import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileService {
  constructor() {}

  changeFileToBase64(file: any): Observable<any> {
    const reader = new FileReader();
    let base64 = '';
    const fileReadSubscriber = (observer) => {
    reader.onload =  (evn: any) => {
      base64 = btoa(evn.target.result);
      observer.next(base64);
      observer.complete();
    };

    reader.readAsBinaryString(file);
  };
    const observable = new Observable(fileReadSubscriber);
    return observable;
  }
}
