import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  // private apiUrl = 'http://fraudaiml1.herokuapp.com/';
  private apiUrl = '/CONTMALERT/';
  private userApiUrl = '/services/userapi/currentUser';
  constructor(private http: HttpClient) {}
  getLoggedInUser(): Observable<any> {
    const observable = this.http.get<any>(this.userApiUrl)
    .pipe(map(data => data.name));
    return observable;
  }

   sendNotes(note: any): Observable<[]> {
     const observable = this.http
   .post<any>(this.apiUrl + 'alertnotes/ ', note);
     return observable;
   }

  getAlerts(user: string): Observable<[]> {
    const header = new HttpHeaders();
    header.append('Content-type', 'application/json');
    const param = new HttpParams().set('recipient', encodeURIComponent(user));
    const observable = this.http
      .get<any>(this.apiUrl + 'alertapi/', {params: param})
      .pipe(
        map(data => {
          return data.map(d => d.fields);
        })
      );
    return observable;
  }

  // getAlertData(alertId: string): Observable<any> {
  //   const param = new HttpParams().set('alertname', encodeURIComponent(alertId));
  //   const observable = this.http
  //     .get<any>(this.apiUrl + 'alertid/', {params: param})
  //     .pipe(
  //       map(data => {

  //         if (data[0]) {
  //           const parameters = data[0].fields.parameters;
  //           if (parameters) {
  //             if (Object.keys(parameters).length === 0) {
  //               data[0].fields.parameters = '';
  //             }
  //           }
  //           return data[0].fields;
  //         }
  //         return data;
  //       })
  //     );

  //   return observable;
  // }
  getAlertData(alertId: string, check: number): Observable<any> {
    // const param = new HttpParams().set('alertname', encodeURIComponent(alertId));
    // alertId = 'alert41';
    const observable = this.http
      .get<any>(this.apiUrl + 'alertid/?alertname=' + alertId + '&check=' + check)
      .pipe(
        map(data => {

          if (data[0]) {
            const parameters = data[0].fields.parameters;
            if (parameters) {
              if (Object.keys(parameters).length === 0) {
                data[0].fields.parameters = '';
              }
            }
            return data[0].fields;
          }
          return data;
        })
      );

    return observable;
  }
  getRecipients(): Observable<any> {
    const observable = this.http.get<Array<any>>(this.apiUrl + 'alertrecipient/')
    .pipe(
      map((data) => {
        return  data.map(d => d.fields.user_id);
      })
    );
    return observable;
  }
  forward(toUser, alertName, attachments, userId): Observable<any> {
    const observableFwd = this.http.post(this.apiUrl + 'alertforward/', {
      recipient: toUser,
      alertname: alertName,
      attachment: attachments,
      createdby:  'P2001620344' // userId
    });
    return observableFwd;
  }
  sendCheckData( checkarray: any): Observable<any> {

    const observable = this.http.post<any>(this.apiUrl + 'markdup/', {
      list: checkarray,
    })
      .pipe(
        map((data) => {
          return data;
        })
      );
    return observable;
  }

}
