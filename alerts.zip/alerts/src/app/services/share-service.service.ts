import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Dialog } from '../models/dialog';

@Injectable({
  providedIn: 'root'
})
export class ShareService {
  private dialogStateData: Dialog = {
    show: false,
    type: '',
    error: ''
  };
  private alertSource = new BehaviorSubject({});
  currentAlert$ = this.alertSource.asObservable();

  private busyStateSource = new BehaviorSubject(false);
  currentBusyState$ = this.busyStateSource.asObservable();

  private masterSource = new BehaviorSubject({});
  masterState$ = this.masterSource.asObservable();

  private filtertextSource = new BehaviorSubject('');
  filterTextState$ = this.filtertextSource.asObservable();

  private resultDialogSource = new BehaviorSubject(this.dialogStateData);
  resultDialogState$ = this.resultDialogSource.asObservable();

  constructor() { }

  changeAlert(alertInfo: any) {
    this.alertSource.next(alertInfo);
  }

  changeBusyState(state: boolean) {
    this.busyStateSource.next(state);
  }
  changeMasterData(data: any) {
    this.masterSource.next(data);

  }
  filter(text: string) {
    this.filtertextSource.next(text);
  }
  changeDialogState(data: Dialog) {
    this.resultDialogSource.next(data);
  }
  showError(errorMsg): Dialog {
    let dialogInfo: Dialog;
    dialogInfo = {
      show : true,
      type : 'error',
      error : errorMsg
    };
    return dialogInfo;
  }
}
