import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';


// -----------------------UI5 components---------------------------
import '@ui5/webcomponents/dist/TableColumn.js';
import '@ui5/webcomponents/dist/CheckBox';

import '@ui5/webcomponents/dist/Table.js';
import '@ui5/webcomponents/dist/TableRow.js';
import '@ui5/webcomponents/dist/TableCell.js';
import '@ui5/webcomponents/dist/Button';
import '@ui5/webcomponents-fiori/dist/ShellBar';
import '@ui5/webcomponents/dist/Title';
import '@ui5/webcomponents/dist/Input';
import '@ui5/webcomponents/dist/DatePicker';
import '@ui5/webcomponents/dist/List';
import '@ui5/webcomponents/dist/CustomListItem';
import '@ui5/webcomponents/dist/Panel';
import '@ui5/webcomponents/dist/Dialog';
import '@ui5/webcomponents/dist/Label';
import '@ui5/webcomponents/dist/TextArea';
import '@ui5/webcomponents/dist/BusyIndicator';
import '@ui5/webcomponents/dist/Link';
import '@ui5/webcomponents/dist/StandardListItem';
import '@ui5/webcomponents/dist/Select';
import '@ui5/webcomponents/dist/Option';
// import '@ui5/webcomponents-icons/dist/Icon/';
// import '@ui5/webcomponents-icons/dist/json-imports/Icons.js'; //alternate import for all icons
import '@ui5/webcomponents-icons/dist/icons/add.js';
import '@ui5/webcomponents-icons/dist/icons/download.js';
import '@ui5/webcomponents-icons/dist/icons/accept.js';
import '@ui5/webcomponents-icons/dist/icons/pending.js';
import '@ui5/webcomponents-icons/dist/icons/forward.js';
import '@ui5/webcomponents-icons/dist/icons/hint.js';
import '@ui5/webcomponents-icons/dist/icons/notes.js';
import '@ui5/webcomponents-icons/dist/icons/action.js';
import '@ui5/webcomponents-icons/dist/icons/employee.js';
import '@ui5/webcomponents-icons/dist/icons/activities.js';
import '@ui5/webcomponents/dist/TabContainer';
import '@ui5/webcomponents/dist/Tab';
import '@ui5/webcomponents/dist/TabSeparator';
import '@ui5/webcomponents/dist/MessageStrip';
import '@ui5/webcomponents/dist/Badge';
import '@ui5/webcomponents-icons/dist/icons/person-placeholder';
import '@ui5/webcomponents-icons/dist/icons/feeder-arrow';
import '@ui5/webcomponents/dist/json-imports/i18n.js';
// ---------------------------------------------------------------

// ---------------------------UI components------------------------------------------------
import { MasterComponent } from './components/master/master.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { MainViewComponent } from './components/main-view/main-view.component';
import { DetailComponent } from './components/detail/detail.component';
import { DetailNavbarComponent } from './components/detail-navbar/detail-navbar.component';
import { DetailFooterComponent } from './components/detail-footer/detail-footer.component';
import { DetailPageComponent } from './components/detail-page/detail-page.component';
import { BusyDialogComponent } from './components/busy-dialog/busy-dialog.component';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { DetailPageInfoComponent } from './components/detail-page-info/detail-page-info.component';
import { ResultViewComponent } from './components/result-view/result-view.component';
import { DownloadSectionComponent } from './components/download-section/download-section.component';
import { ErrorSectionComponent } from './components/error-section/error-section.component';
import { SuccessSectionComponent } from './components/success-section/success-section.component';
import { DialogSectionComponent } from './components/dialog-section/dialog-section.component';
import { DetailPageNotesComponent } from './components/detail-page-notes/detail-page-notes.component';
import { ResultTableComponent } from './components/result-table/result-table.component';
// ----------------------------------------------------------------------------------------

@NgModule({
  declarations: [
    AppComponent,
    MasterComponent,
    NavbarComponent,
    MainViewComponent,
    DetailComponent,
    DetailNavbarComponent,
    DetailFooterComponent,
    DetailPageComponent,
    BusyDialogComponent,
    ErrorPageComponent,
    NotFoundComponent,
    DetailPageInfoComponent,
    ResultViewComponent,
    DownloadSectionComponent,
    ErrorSectionComponent,
    SuccessSectionComponent,
    DialogSectionComponent,
    DetailPageNotesComponent,
    ResultTableComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  schemas : [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
