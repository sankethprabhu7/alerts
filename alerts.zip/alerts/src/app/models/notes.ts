export interface NoteModel {
    alertname: string;
    user: string;
    time: Date;
    notes: string;
}
