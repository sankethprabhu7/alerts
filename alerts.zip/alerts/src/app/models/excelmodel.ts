export interface ExcelModel {
    index: string;
    document_no: string;
    vendor_no: string;
    vendor_amount: string;
    payment_term: string;
}
