export interface Dialog {
    show: boolean;
    type: string;
    error?: string;
}
