export interface Ireport {
    status: string;
    alert_name: string;
    recipient: string;
    created_by: string;
    scenario: string;
     created_on: string;
     alert_type: string;
     run_id: string;
}

